<?php $__env->startSection('title'); ?>
    Edit Service Price
<?php $__env->stopSection(); ?>

<?php $__env->startSection('links'); ?>

    <link href="<?php echo e(asset('css/profile.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/error.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .header {
            position: absolute;
            top: -14px;
            left: 1%;
            padding: 0% 2px;
            margin: 0%;
            background: white!important;
        }

        .borderdiv {
            position: relative;
            padding: 32px;
            border-radius: 10px;
            border: 2px solid #75b3e2;
            margin-top: 2rem;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container emp-profile mt-3">
        <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('admin.price.update', $price->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-group font-weight-bold">
                <label for="name">Service Type:</label>
                <input type="text" class="form-control" value="<?php echo e($price->name); ?>" name="name" placeholder="Enter Name">
            </div>

            <div class="form-group font-weight-bold">
                <label for="days">No Of Days : </label>
                <input type="number" class="form-control" value="<?php echo e($price->days); ?>"  name="days" placeholder="Enter days">
            </div>

            <div class="form-group font-weight-bold">
                <label for="timing">Timings:</label>
                <input type="text" class="form-control" name="timing" value="<?php echo e($price->timing); ?>" placeholder="Enter timing eg : 6 AM to 7 PM">
            </div>

            <div class="form-group font-weight-bold">
                <label for="price">Price Per month:</label>
                <input type="number" class="form-control" name="price" value="<?php echo e($price->price); ?>"  placeholder="Enter price">
            </div>

            <div class="form-group font-weight-bold">
                <label for="period">Period (Day/night/full):</label>
                <input type="text"  class="form-control" name="period" value="<?php echo e($price->period); ?>" placeholder="enter period">
            </div>


            <button class="btn btn-primary" type="submit">Create</button>

        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nabajyoti\Documents\Laravel\NursingWebApp\resources\views/admin/price/edit.blade.php ENDPATH**/ ?>