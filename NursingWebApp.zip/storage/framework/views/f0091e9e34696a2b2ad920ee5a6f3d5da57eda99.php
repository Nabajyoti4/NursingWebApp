<!-- navbar -->
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>
    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">




        <!-- Nav Item - User Information -->
        <!-- Authentication Links -->
        <?php if(auth()->guard()->check()): ?>
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                   data-toggle="dropdown"
                   aria-haspopup="true" aria-expanded="false">
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(Auth::user()->name); ?></span>
                    <img class="img-profile rounded-circle"
                         src="<?php echo e(Auth::user()->photo?asset("/storage/".Auth::user()->photo->photo_location):asset('img/avatar1.png')); ?>">
                </a>
                <!-- Dropdown - User Information -->
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                     aria-labelledby="userDropdown">
                    <?php if(Auth::user()->role==="nurse"): ?>
                        <a class="dropdown-item" href="<?php echo e(route('nurse.index')); ?>">
                            <i class="fas fa-user-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                            Profile
                        </a>
                    <?php else: ?>
                    <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>">
                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                        Profile
                    </a>
                    <?php endif; ?>
                    <a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">
                        <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                        Admin Panel
                    </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" data-toggle="modal" data-target="#logoutModal">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                        <?php echo e(__('Logout')); ?>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                              style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </a>

                </div>
            </li>
        <?php else: ?>
            <li class="nav-item px-1 ">
                <a class="nav-link  navbar-fonts" href="<?php echo e(route('login')); ?>">Login/register</a>
                
            </li>
        <?php endif; ?>


    </ul>

</nav>
<!-- End of Topbar -->
<?php /**PATH C:\Users\Nabajyoti\Documents\Laravel\NursingWebApp\resources\views/partials/admin_navbar.blade.php ENDPATH**/ ?>