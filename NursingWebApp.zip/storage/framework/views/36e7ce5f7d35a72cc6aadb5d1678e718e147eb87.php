<?php $__env->startSection('title'); ?>
    Ratings
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: '<?php echo e($message); ?>',
                showConfirmButton: true,
            })
        </script>
    <?php endif; ?>
    <!-- Search -->

    <div class="d-sm-inline-block justify-content-end">
        <a class="btn btn-primary" href="<?php echo e(route('admin.rating.create')); ?>">
            create
            <i class="fa fa-user-plus" aria-hidden="true"></i>
        </a>
    </div>
    <hr>

    <!-- Nurse table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Rating</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>Nurse Name</th>
                        <th>Stars</th>
                        <th>Avatar</th>
                        <th>Remark</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($rating->name); ?></td>
                            <td><?php echo e($rating->star); ?></td>
                            <td>   <img
                                    src="<?php echo e(asset("/storage/".$rating->photo)); ?>"
                                    alt="" width="100" height="100"
                                /></td>
                            <td><?php echo e($rating->remark); ?></td>
                            <td><a class="btn btn-primary small"
                                   href="<?php echo e(route('admin.rating.edit',$rating->id)); ?>">Edit</a>
                            </td>
                            <td>
                                <form action="<?php echo e(route('rating.destroy', $rating->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"  class="btn btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">No Ratings found</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nabajyoti\Documents\Laravel\NursingWebApp\resources\views/admin/rating/index.blade.php ENDPATH**/ ?>