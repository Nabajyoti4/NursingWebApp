<?php $__env->startSection('title'); ?>
    Patients
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Search -->
    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="<?php echo e(route('admin.patient.approved')); ?>"
          method="GET">
        <?php echo csrf_field(); ?>
        <div class="input-group">
            <input type="text" class="form-control border-2 small" name="patient" placeholder="Search for..."
                   aria-label="Search" aria-describedby="basic-addon2">
            <div class="input-group-append">
                <button class="btn btn-primary" type="submit">
                    <i class="fas fa-search fa-sm"></i>
                </button>
            </div>
        </div>
    </form>

    <hr>

    <!-- DataTales Example -->
    <div class="card shadow mb-4" id="nurseTable">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Patients</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>Patient ID</th>
                        <th>Name</th>
                        <th>Phone No</th>
                        <th>Age</th>
                        <th>Status</th>
                        <th>View</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($patient->id); ?></td>
                            <td><?php echo e($patient->patient_name); ?></td>
                            <td><?php echo e($patient->phone_no); ?></td>
                            <td><?php echo e($patient->age); ?></td>
                            <td>
                                <?php if($patient->status == 1): ?>
                                    Approved
                                <?php elseif($patient->status == 0): ?>
                                    Disapproved
                                <?php else: ?>
                                    Pending
                                <?php endif; ?>
                            </td>
                            <td>
                                <form action="<?php echo e(route('admin.patient.show',$patient->id)); ?>" method="GET">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-primary"  type="submit">View Detials</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">No Patients found</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script>
        function handleDisapprove(id){

            var message = document.getElementById('disapproveRequestMessage')

            message.action = "/nursejoin/" + id + "/disapprove"

            $('#disapproveModal').modal('show')
        }

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nabajyoti\Documents\Laravel\NursingWebApp\resources\views/admin/patients/index.blade.php ENDPATH**/ ?>