<?php $__env->startSection('title'); ?>
    Create Service
<?php $__env->stopSection(); ?>

<?php $__env->startSection('links'); ?>

    <link href="<?php echo e(asset('css/profile.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/error.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .header {
            position: absolute;
            top: -14px;
            left: 1%;
            padding: 0% 2px;
            margin: 0%;
            background: white !important;
        }

        .borderdiv {
            position: relative;
            padding: 32px;
            border-radius: 10px;
            border: 2px solid #75b3e2;
            margin-top: 2rem;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container emp-profile mt-3 mb-5">
        <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('admin.services.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>


            <div class="form-group font-weight-bold">
                <label for="title">Service:</label>
                <input required type="text" class="form-control" name="title"  placeholder="Enter service">
            </div>


            <div class="form-group font-weight-bold">
                <label for="details">Description:</label>
                <textarea required rows="5" cols="200" type="text" class="form-control" name="details"  placeholder="Enter details"></textarea>
            </div>

            <div class="form-group font-weight-bold">
                <label for="list">Services:</label>
                <textarea rows="3" cols="200"  type="text" class="form-control" name="list"  placeholder="Enter services"></textarea>
            </div>

            <div class="form-group font-weight-bold">
                <label for="cover">Upload Cover Pic: </label>
                <input required type="file" class="form-control" name="cover">
            </div>

            <br>
            <button class="btn btn-primary" type="submit">Create</button>

        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nabajyoti\Documents\Laravel\NursingWebApp\resources\views/admin/services/create.blade.php ENDPATH**/ ?>