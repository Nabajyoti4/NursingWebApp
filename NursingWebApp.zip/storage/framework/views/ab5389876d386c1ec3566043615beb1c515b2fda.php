<?php $__env->startSection('title'); ?>
    Admins
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: '<?php echo e($message); ?>',
                showConfirmButton: true,
            })
        </script>
    <?php endif; ?>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Queries</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>District</th>
                        <th>Email</th>
                        <th>Query</th>
                        <th>Created at</th>
                        <th>Responded</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $queries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($query->name); ?></td>
                            <td><?php echo e($query->phone); ?></td>
                            <td><?php echo e($query->city); ?></td>
                            <td><?php echo e($query->email); ?></td>
                            <td><?php echo e($query->query); ?></td>
                            <td><?php echo e($query->created_at); ?></td>
                            <td><?php if($query->status == 0): ?>
                                <a class="btn btn-primary small" href="<?php echo e(route('admin.query.update',$query->id)); ?>">Mark Done
                                </a><i class="fa fa-pencil-square" aria-hidden="true"></i>
                                <?php else: ?>
                                    Responded Successfully
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">No Pending Queries found</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nabajyoti\Documents\Laravel\NursingWebApp\resources\views/admin/query/index.blade.php ENDPATH**/ ?>