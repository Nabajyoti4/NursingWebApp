<?php $__env->startSection('title'); ?>
    Edit Service
<?php $__env->stopSection(); ?>

<?php $__env->startSection('links'); ?>

    <link href="<?php echo e(asset('css/profile.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/error.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="container emp-profile mt-3">
        <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('admin.services.update', $service->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-group font-weight-bold">
                <label for="title">Service:</label>
                <input type="text" class="form-control" value="<?php echo e($service->title); ?>" name="title"  placeholder="Enter service">
            </div>


            <div class="form-group font-weight-bold">
                <label for="details">Description:</label>
                <textarea rows="5" cols="200" type="text" class="form-control" name="details"  placeholder="Enter details"><?php echo e($service->details); ?></textarea>
            </div>

            <div class="form-group font-weight-bold">
                <label for="list">Services:</label>
                <textarea rows="3" cols="200"  type="text" class="form-control" name="list"  placeholder="Enter services"><?php echo e($service->list); ?></textarea>
            </div>

            <div class="form-group font-weight-bold">
                <label for="cover">Upload Cover Pic: </label>
                <input type="file" class="form-control" name="cover">
            </div>

            <br>
            <button class="btn btn-primary" type="submit">Update</button>

        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nabajyoti\Documents\Laravel\NursingWebApp\resources\views/admin/services/edit.blade.php ENDPATH**/ ?>