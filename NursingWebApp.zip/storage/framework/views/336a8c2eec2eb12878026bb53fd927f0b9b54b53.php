


<nav class="navbar navbar-expand-md navbar-light shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('img/AArogya-new-edit-1.png')); ?>"
                 style="width: 180px; height: 70px; background: #fff; padding: 10px; border-radius: 4px; color: #28669F;"
                 alt="">
        </a>
        <button class="navbar-toggler navbar-toggler-right hidden-md-up mt-2" type="button" data-target="#stage"
                data-toggle="stage" data-distance="-250">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto">

            </ul>

            <!-- Right Side Of Navbar -->
            <div class="navbar-nav ml-auto">
                <li class="nav-item px-1 ">
                    <a class="nav-link navbar-fonts" href="<?php echo e(url('/')); ?>">Home</a>
                </li>
                <li class="nav-item px-1 ">
                    <a class="nav-link navbar-fonts" href="<?php echo e(route('user.service.index')); ?>">Services</a>
                </li>
                <li class="nav-item px-1 ">
                    <a class="nav-link navbar-fonts" href="<?php echo e(route('contact_us')); ?>">Contact Us</a>
                </li>
                <li class="nav-item px-1 ">
                    <a class="nav-link navbar-fonts" href="<?php echo e(route('about_us')); ?>">About Us</a>
                </li>
                <li class="nav-link navbar-fonts">|</li>
                <!-- Authentication Links -->
                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle navbar-fonts" href="#"
                           role="button"
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                            <img class="rounded-circle" style="object-fit: fill" width="40px" height="38px"
                                 src="<?php echo e(Auth::user()->photo?asset("/storage/".Auth::user()->photo->photo_location):asset('img/avatar1.png')); ?>">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                             aria-labelledby="userDropdown">
                            <?php if(Auth::user()->role==="nurse"): ?>
                                <a class="dropdown-item" href="<?php echo e(route('nurse.index')); ?>">
                                    <i class="fas fa-user-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                            <?php else: ?>
                                <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>

                            <?php endif; ?>
                            <?php if(Auth::user()->role === 'admin' or Auth::user()->role === 'super'): ?>
                            <a class="dropdown-item" href="<?php echo e(route('admin.index')); ?>">
                                <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                Admin Panel
                            </a>
                                <?php endif; ?>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                      style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </a>

                        </div>


                    </li>
                <?php else: ?>
                    <li class="nav-item px-1 ">
                        <a class="nav-link  navbar-fonts" href="<?php echo e(route('login')); ?>">Login/register</a>
                        
                    </li>
                    <?php endif; ?>
                    </ul>
            </div>
        </div>
</nav>

<?php /**PATH C:\Users\Nabajyoti\Documents\Laravel\NursingWebApp\resources\views/partials/navbar.blade.php ENDPATH**/ ?>