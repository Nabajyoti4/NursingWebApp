<?php $__env->startSection('title'); ?>
    Services
<?php $__env->stopSection(); ?>

<?php $__env->startSection('links'); ?>
    <script src="<?php echo e(asset('js/sweetalert2.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: <?php echo e($message); ?>,
                showConfirmButton: true,
            })
        </script>
        <?php endif; ?>
    <div class="d-sm-inline-block justify-content-end">
        <a class="btn btn-primary" href="<?php echo e(route('admin.services.create')); ?>">
            Create Service
            <i class="fa fa-user-plus" aria-hidden="true"></i>
        </a>
    </div>
    <hr>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Service</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive" >
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th>Service ID</th>
                        <th>Service</th>
                        <th>Service list</th>
                        <th>Cover image</th>
                        <th>Delete</th>
                        <th>Edit</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($service->title); ?></td>
                            <td><?php echo e($service->details); ?></td>
                            <td><?php echo e($service->list); ?></td>
                            <td><img
                                    src="<?php echo e(asset("/storage/".$service->cover)); ?>"
                                    alt="" width="100" height="100"
                                /></td>
                            <td>
                                <form action="<?php echo e(route('services.destroy', $service->id)); ?>" method="POST">
                                 <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">DELETE</button>
                                </form>
                            </td>
                            <td><a class="btn btn-primary small" href="<?php echo e(route('admin.services.edit',$service->id)); ?>">Edit</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">No services found</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nabajyoti\Documents\Laravel\NursingWebApp\resources\views/admin/services/index.blade.php ENDPATH**/ ?>