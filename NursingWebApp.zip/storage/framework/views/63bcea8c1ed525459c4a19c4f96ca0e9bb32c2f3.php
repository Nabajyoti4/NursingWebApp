<?php $__env->startSection('title'); ?>
    Edit Rating
<?php $__env->stopSection(); ?>

<?php $__env->startSection('links'); ?>

    <link href="<?php echo e(asset('css/profile.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/error.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .header {
            position: absolute;
            top: -14px;
            left: 1%;
            padding: 0% 2px;
            margin: 0%;
            background: white!important;
        }

        .borderdiv {
            position: relative;
            padding: 32px;
            border-radius: 10px;
            border: 2px solid #75b3e2;
            margin-top: 2rem;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container emp-profile mt-3">
        <?php echo $__env->make('partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('admin.rating.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group font-weight-bold">
                <label for="name">Full Name:</label>
                <input type="text" class="form-control" name="name" placeholder="Enter Name">
            </div>

            <div class="form-group font-weight-bold">
                <label for="star">Stars:</label>
                <input type="number" min="1" max="5" class="form-control" name="star" placeholder="Enter rating between 1 to 5">
            </div>

            <div class="form-group font-weight-bold">
                <label for="remark">Remark :</label>
                <textarea type="text" class="form-control" name="remark"  placeholder="remark"></textarea>
            </div>


            <div class="form-group font-weight-bold">
                <label for="photo">Upload Profile Pic: </label>
                <input type="file" class="form-control" name="photo">
            </div>


            <button class="btn btn-primary" type="submit">Create</button>

        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nabajyoti\Documents\Laravel\NursingWebApp\resources\views/admin/rating/create.blade.php ENDPATH**/ ?>